from setuptools import setup

setup(
    name="paquetecalculos",
    version="1.0",
    description="Paquete de redonde y potencia",
    author="Samuel",
    author_email="gskdante@gmail.com",
    url="www.goggle.com",
    packages=["calculos", "calculos.redondeo_potencia"]
)